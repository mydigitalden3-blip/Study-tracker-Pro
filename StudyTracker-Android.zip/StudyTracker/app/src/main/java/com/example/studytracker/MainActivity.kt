package com.example.studytracker

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private enum class Tab { TODAY, CALENDAR, STATS }

private data class DayStat(val date: LocalDate, val minutes: Int)

private class StudyStore(context: Context) {
    private val prefs = context.getSharedPreferences("study_tracker", Context.MODE_PRIVATE)

    fun loadDaily(): MutableMap<String, Int> = prefs.all.mapNotNull { (k, v) ->
        if (k.startsWith("d_")) k.removePrefix("d_").let { date -> date to (v as? Int ?: 0) } else null
    }.toMap().toMutableMap()

    fun saveDay(date: LocalDate, minutes: Int) {
        prefs.edit().putInt("d_${date}", minutes).apply()
    }

    fun running(): Boolean = prefs.getBoolean("running", false)
    fun setRunning(value: Boolean) = prefs.edit().putBoolean("running", value).apply()
    fun startedAtElapsed(): Long = prefs.getLong("started_elapsed", 0L)
    fun setStartedAtElapsed(value: Long) = prefs.edit().putLong("started_elapsed", value).apply()

    fun savedTimerSeconds(): Long = prefs.getLong("timer_seconds", 0L)
    fun setSavedTimerSeconds(value: Long) = prefs.edit().putLong("timer_seconds", value).apply()

    fun clearTimer() = prefs.edit().putLong("timer_seconds", 0L).putBoolean("running", false).putLong("started_elapsed", 0L).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudyTrackerApp(applicationContext)
        }
    }
}

@Composable
private fun StudyTrackerApp(context: Context) {
    val store = remember { StudyStore(context) }
    var tab by remember { mutableStateOf(Tab.TODAY) }
    var daily by remember { mutableStateOf(store.loadDaily()) }
    val today = LocalDate.now()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Scaffold(
            bottomBar = {
                NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                    NavigationBarItem(selected = tab == Tab.TODAY, onClick = { tab = Tab.TODAY }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Today") })
                    NavigationBarItem(selected = tab == Tab.CALENDAR, onClick = { tab = Tab.CALENDAR }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendar") })
                    NavigationBarItem(selected = tab == Tab.STATS, onClick = { tab = Tab.STATS }, icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("Stats") })
                }
            }
        ) { pad ->
            when (tab) {
                Tab.TODAY -> TodayScreen(store, daily, { daily = store.loadDaily() }, Modifier.padding(pad))
                Tab.CALENDAR -> CalendarScreen(daily, Modifier.padding(pad))
                Tab.STATS -> StatsScreen(daily, Modifier.padding(pad))
            }
        }
    }
}

@Composable
private fun TodayScreen(store: StudyStore, daily: Map<String, Int>, refresh: () -> Unit, modifier: Modifier) {
    val today = LocalDate.now()
    val totalToday = daily[today.toString()] ?: 0
    var timerSeconds by remember { mutableLongStateOf(store.savedTimerSeconds()) }
    var running by remember { mutableStateOf(store.running()) }

    LaunchedEffect(running) {
        if (running) {
            while (true) {
                timerSeconds = store.savedTimerSeconds() + ((SystemClock.elapsedRealtime() - store.startedAtElapsed()).coerceAtLeast(0L) / 1000L)
                kotlinx.coroutines.delay(1000)
            }
        }
    }

    fun start() {
        if (!running) {
            store.setStartedAtElapsed(SystemClock.elapsedRealtime())
            store.setRunning(true)
            running = true
        }
    }

    fun pause() {
        if (running) {
            val current = timerSeconds
            store.setSavedTimerSeconds(current)
            store.setRunning(false)
            running = false
        }
    }

    fun reset() {
        store.clearTimer()
        timerSeconds = 0L
        running = false
    }

    fun finish() {
        val secs = timerSeconds
        val mins = (secs / 60.0).roundToInt()
        if (mins > 0) {
            val newTotal = totalToday + mins
            store.saveDay(today, newTotal)
        }
        reset()
        refresh()
    }

    LazyColumn(modifier = modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("Study Tracker", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(
                today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 15.sp
            )
        }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(8.dp))
                        Text("Open Timer", fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(formatDuration(timerSeconds), fontSize = 56.sp, fontWeight = FontWeight.Bold)
                    Text(if (running) "Studying now" else "No time limit", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (running) {
                            OutlinedButton(onClick = ::pause) { Icon(Icons.Default.Pause, null); Spacer(Modifier.size(6.dp)); Text("Pause") }
                        } else {
                            Button(onClick = ::start) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.size(6.dp)); Text("Start") }
                        }
                        OutlinedButton(onClick = ::finish, enabled = timerSeconds > 0) { Icon(Icons.Default.Stop, null); Spacer(Modifier.size(6.dp)); Text("Save") }
                        IconButton(onClick = ::reset, enabled = timerSeconds > 0) { Icon(Icons.Default.Refresh, contentDescription = "Reset") }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Today", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("$totalToday", fontWeight = FontWeight.Bold, fontSize = 34.sp)
                        Spacer(Modifier.size(6.dp))
                        Text("min studied", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 5.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { (totalToday / 240f).coerceAtMost(1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text("Daily guide: 4 hours", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
        item {
            val streak = calculateStreak(daily)
            Card(shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatMini("🔥", "$streak days", "Current streak")
                    StatMini("📚", "${daily.values.sum()} min", "All-time logged")
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun StatMini(icon: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(0.48f)) {
        Text(icon, fontSize = 22.sp)
        Text(value, fontWeight = FontWeight.Bold)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CalendarScreen(daily: Map<String, Int>, modifier: Modifier) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    val title = month.month.name.lowercase(Locale.getDefault()).replaceFirstChar { it.uppercase() }

    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Calendar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("See your study history at a glance", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
                    Text("$title ${month.year}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
                }
                Row(Modifier.fillMaxWidth()) {
                    listOf("M", "T", "W", "T", "F", "S", "S").forEach { d ->
                        Text(d, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                val first = month.atDay(1)
                val startOffset = first.dayOfWeek.value - DayOfWeek.MONDAY.value
                val days = month.lengthOfMonth()
                val cells = (startOffset + days + 6) / 7 * 7
                for (row in 0 until cells / 7) {
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0..6) {
                            val index = row * 7 + col
                            val dayNumber = index - startOffset + 1
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                                if (dayNumber in 1..days) {
                                    val date = month.atDay(dayNumber)
                                    val mins = daily[date.toString()] ?: 0
                                    val intensity = when {
                                        mins >= 120 -> 1f
                                        mins >= 60 -> 0.8f
                                        mins >= 30 -> 0.55f
                                        mins > 0 -> 0.3f
                                        else -> 0f
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                                        modifier = Modifier.fillMaxSize().clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = intensity))) {
                                        Text(dayNumber.toString(), fontSize = 13.sp, fontWeight = if (date == LocalDate.now()) FontWeight.Bold else FontWeight.Normal)
                                        if (mins > 0) Text("${mins}m", fontSize = 8.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Recent days", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Spacer(Modifier.height(8.dp))
        val recent = daily.mapNotNull { (date, mins) -> runCatching { DayStat(LocalDate.parse(date), mins) }.getOrNull() }
            .filter { it.minutes > 0 }
            .sortedByDescending { it.date }
            .take(7)
        if (recent.isEmpty()) {
            Text("No study sessions saved yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recent) { s ->
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(s.date.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault())))
                            Text("${s.minutes} min", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsScreen(daily: Map<String, Int>, modifier: Modifier) {
    val total = daily.values.sum()
    val activeDays = daily.count { it.value > 0 }
    val average = if (activeDays == 0) 0 else total / activeDays
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Stats", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Simple numbers, no clutter", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            BigStat("$total", "Total minutes", Modifier.weight(1f))
            BigStat("$activeDays", "Active days", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        BigStat("$average", "Average minutes per active day", Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("Last 7 days", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Spacer(Modifier.height(12.dp))
                val start = LocalDate.now().minusDays(6)
                for (i in 0..6) {
                    val date = start.plusDays(i.toLong())
                    val mins = daily[date.toString()] ?: 0
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 5.dp)) {
                        Text(date.dayOfWeek.name.take(3), modifier = Modifier.size(32.dp))
                        LinearProgressIndicator(progress = { (mins / 180f).coerceAtMost(1f) }, modifier = Modifier.weight(1f))
                        Text(" ${mins}m", modifier = Modifier.size(44.dp), textAlign = TextAlign.End, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BigStat(value: String, label: String, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(value, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
    }
}

private fun calculateStreak(daily: Map<String, Int>): Int {
    var date = LocalDate.now()
    var streak = 0
    while ((daily[date.toString()] ?: 0) > 0) {
        streak++
        date = date.minusDays(1)
    }
    return streak
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s)
}
